<?php include "include/header.php"; ?>





    <div class="owl-carousel-wrapper">

      

      <div class="box-92819 shadow-lg">
        

          <div>
            <h1 class=" mb-3 text-black">Delhi Housing Infra & Developer</h1>
            <p>Interior design is the art and science of enhancing the interior of a space to create a more aesthetically pleasing and functional environment.</p>
            <p class="mb-0 mt-4"><a href="contact.php" class="btn btn-primary">Get In Touch</a></p>
          </div>

          

        
      </div>



      <div class="owl-carousel owl-1 ">
        <div class="ftco-cover-1" style="background-image: url('images/hero_1.jpg');"></div>
        <div class="ftco-cover-1" style="background-image: url('images/hero_2.jpg');"></div>
        <div class="ftco-cover-1" style="background-image: url('images/hero_3.jpg');"></div>
        
      </div>
    </div>  

    <div class="site-section">
      <div class="container">
        <div class="row mb-5 align-items-center">
          <div class="col-md-7">
            <h2 class="heading-39291 mb-0">Our Work</h2>
          </div>
          <div class="col-md-5 text-right">
            <p class="mb-0"><a href="services.php" class="more-39291">View All Works</a></p>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-6">
            <div class="media-02819">
              <a href="#" class="img-link"><img src="images/img_1.jpg" alt="Image" class="img-fluid" style="width: 800px; height: 650px;"></a>
              <h3><a href="#">MODULAR KITCHEN</a></h3>
              <!-- <span>New York City, USA</span> -->
            </div>
          </div>
          <div class="col-lg-6">
            <div class="media-02819">
              <a href="#" class="img-link"><img src="images/img_2.jpg" alt="Image" class="img-fluid" style="width: 800px; height: 650px;"></a>
              <h3><a href="#">DINING ROOM DESIGNS</a></h3>
              <!-- <span>New York City, USA</span> -->
            </div>
          </div>

          <div class="col-lg-6">
            <div class="media-02819">
              <a href="#" class="img-link"><img src="images/img_3.jpg" alt="Image" class="img-fluid" style="width: 800px; height: 650px;"></a>
              <h3><a href="#">LIVING ROOM DESIGNS</a></h3>
              <!-- <span>New York City, USA</span> -->
            </div>
          </div>
          <div class="col-lg-6">
            <div class="media-02819">
              <a href="#" class="img-link"><img src="images/img_4.jpg" alt="Image" class="img-fluid" style="width: 800px; height: 650px;"></a>
              <h3><a href="#">MASTER BEDROOM DESIGNS</a></h3>
              <!-- <span>New York City, USA</span> -->
            </div>
          </div>

        </div>
      </div>
    </div>


    <div class="site-section bg-primary">
      <div class="container">
        <div class="row mb-5 align-items-center">
          <div class="col-md-7">
            <h2 class="heading-39291 text-white mb-3">What We Do</h2>
            <p class="text-white">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis velit iure possimus repellendus, esse minus illum nobis deleniti?</p>
          </div>
        </div>
        <div class="row">
          
          <div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <img src="fonts/flaticon/svg/002-kitchen.svg" alt="Image" class="img-fluid">
              </span>
              <h3 class="mb-4"><a href="#">Kitchen Interiors</a></h3>
              <p>Kitchen interiors play a crucial role in creating a functional and aesthetically pleasing space include U-shaped, L-shaped designs..</p>
            </div>
          </div>
          <div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <img src="fonts/flaticon/svg/003-lamp.svg" alt="Image" class="img-fluid">
              </span>
              <h3 class="mb-4"><a href="#">Modular Interiors</a></h3>
              <p>This concept is widely used in various areas of interior design, including kitchens, living rooms, bedrooms, and office spaces.</p>
            </div>
          </div>

          <div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <img src="fonts/flaticon/svg/001-stairs.svg" alt="Image" class="img-fluid">
              </span>
              <h3 class="mb-4"><a href="#">Full Home Interiors</a></h3>
              <p>Designing the interiors of an entire home involves considering various aspects to create a cohesive and functional living space.</p>
            </div>
          </div>

          <div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <img src="fonts/flaticon/svg/004-blueprint.svg" alt="Image" class="img-fluid">
              </span>
              <h3 class="mb-4"><a href="#">Commercial Interiors</a></h3>
              <p>Designing commercial interiors are not only aesthetically pleasing but also functional and conducive to the specific activities and needs of the business.</p>
            </div>
          </div>
          <div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <img src="fonts/flaticon/svg/006-pantone.svg" alt="Image" class="img-fluid">
              </span>
              <h3 class="mb-4"><a href="#">Renovations</a></h3>
              <p>Renovations involve making improvements or changes to an existing space to enhance its functionality, aesthetics, or both.</p>
            </div>
          </div>
          <div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <img src="fonts/flaticon/svg/005-dinning-table.svg" alt="Image" class="img-fluid">
              </span>
              <h3 class="mb-4"><a href="#">Furniture & decor</a></h3>
              <p>Furniture and decor play a crucial role in shaping the overall look and feel of a space, be it a home, office, or commercial establishment.</p>
            </div>
          </div>
          
        </div>
      </div>
    </div>

    
    <div class="site-section section-4">
      <div class="container">

        <div class="row justify-content-center text-center">
          <div class="col-md-7">
            <div class="slide-one-item owl-carousel">

              <!-- <blockquote class="testimonial-1">
                <span class="quote quote-icon-wrap"><span class="icon-format_quote"></span></span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus totam sit delectus earum facere ex ea sunt, eos?</p>
                <cite><span class="text-black">Mike Dorney</span> &mdash; <span class="text-muted">CEO and Co-Founder</span></cite>
              </blockquote> -->

              <!-- <blockquote class="testimonial-1">
                <span class="quote quote-icon-wrap"><span class="icon-format_quote"></span></span>
                <p>Eligendi earum ad perferendis dolores, dolor quas. Ullam in, eaque mollitia suscipit id aspernatur rerum! Sit quibusdam ullam tempora quis, in voluptatum maiores veritatis recusandae!</p>
                <cite><span class="text-black">James Smith</span> &mdash; <span class="text-muted">CEO and Co-Founder</span></cite>
              </blockquote> -->

              <blockquote class="testimonial-1">
                <span class="quote quote-icon-wrap"><span class="icon-format_quote"></span></span>
                <p> The team not only listened to my ideas but also offered valuable insights and creative solutions that elevated the overall design of my space. Their expertise in interior design is evident in every corner of my home.</p>
                <cite>
                  <!-- <span class="text-black">Mike Dorney</span>  -->
                  <span class="text-muted">Customer Reviews</span></cite>
              </blockquote>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php include "include/footer.php"; ?>
    
