<?php include "include/header.php"; ?>




<!--     <div class="owl-carousel-wrapper">

      <div class="box-92819 shadow-lg">
    
          <div>
            <h1 class=" mb-3 text-black">What We Do</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quam, ratione earum.</p>
          </div>
        
      </div>

        <div class="ftco-cover-1" style="background-image: url('images/hero_1.jpg');"></div>
    </div> -->

    
    <div class="site-section bg-light">
      <div class="container">
        <div class="row mb-5 align-items-center">
          <div class="col-md-7">
            <h2 class="heading-39291 text-black mb-3">Services</h2>
            <p class="text-black">Interior design services encompass a range of professional offerings aimed at enhancing the aesthetics, functionality, and overall appeal of interior spaces. Interior designers work with clients to create cohesive and visually pleasing environments.</p>
          </div>
        </div>
        <div class="row">







<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/MODULAR KITCHEN/mk (1).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
              <img src="images/MODULAR KITCHEN/mk (2).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
              <img src="images/MODULAR KITCHEN/mk (3).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
              <img src="images/MODULAR KITCHEN/mk (4).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
              <img src="images/MODULAR KITCHEN/mk (5).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
              <img src="images/MODULAR KITCHEN/mk (6).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
              <img src="images/MODULAR KITCHEN/mk (7).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
              <img src="images/MODULAR KITCHEN/mk (8).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
              <img src="images/MODULAR KITCHEN/mk (9).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
              <img src="images/MODULAR KITCHEN/mk (10).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">MODULAR KITCHEN</a></h3>
  </div>
</div>




<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/DINING ROOM DESIGNS/dr (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/DINING ROOM DESIGNS/dr (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/DINING ROOM DESIGNS/dr (3).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/DINING ROOM DESIGNS/dr (4).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/DINING ROOM DESIGNS/dr (5).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/DINING ROOM DESIGNS/dr (6).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/DINING ROOM DESIGNS/dr (7).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/DINING ROOM DESIGNS/dr (8).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/DINING ROOM DESIGNS/dr (9).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">DINING ROOM DESIGNS</a></h3>
  </div>
</div>




<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/FOYER DESIGNS/f (1).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
              <img src="images/FOYER DESIGNS/f (2).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
              <img src="images/FOYER DESIGNS/f (3).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
              <img src="images/FOYER DESIGNS/f (4).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
              <img src="images/FOYER DESIGNS/f (5).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
              <img src="images/FOYER DESIGNS/f (6).jpg" alt="Image" class="img-fluid" style=" width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">FOYER DESIGNS</a></h3>
  </div>
</div>




<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/WARDROBE DESIGNS/wd (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/WARDROBE DESIGNS/wd (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/WARDROBE DESIGNS/wd (3).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/WARDROBE DESIGNS/wd (4).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">WARDROBE DESIGNS</a></h3>
  </div>
</div>




<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/BATHROOM DESIGNS/b (1).jpeg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/BATHROOM DESIGNS/b (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/BATHROOM DESIGNS/b (3).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">BATHROOM DESIGNS</a></h3>
  </div>
</div>



<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/MASTER BEDROOM DESIGNS/mb (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/MASTER BEDROOM DESIGNS/mb (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/MASTER BEDROOM DESIGNS/mb (3).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/MASTER BEDROOM DESIGNS/mb (4).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/MASTER BEDROOM DESIGNS/mb (5).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/MASTER BEDROOM DESIGNS/mb (6).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/MASTER BEDROOM DESIGNS/mb (7).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/MASTER BEDROOM DESIGNS/mb (8).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/MASTER BEDROOM DESIGNS/mb (9).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/MASTER BEDROOM DESIGNS/mb (10).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/MASTER BEDROOM DESIGNS/mb (11).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">MASTER BEDROOM DESIGNS</a></h3>
  </div>
</div>






















<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/TILE DESIGNS/t (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/TILE DESIGNS/t (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/TILE DESIGNS/t (3).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/TILE DESIGNS/t (4).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">TILE DESIGNS</a></h3>
  </div>
</div>



<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/LIVING ROOM DESIGNS/lr (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/LIVING ROOM DESIGNS/lr (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/LIVING ROOM DESIGNS/lr (3).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/LIVING ROOM DESIGNS/lr (4).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/LIVING ROOM DESIGNS/lr (5).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/LIVING ROOM DESIGNS/lr (6).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/LIVING ROOM DESIGNS/lr (7).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/LIVING ROOM DESIGNS/lr (8).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/LIVING ROOM DESIGNS/lr (9).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/LIVING ROOM DESIGNS/lr (10).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/LIVING ROOM DESIGNS/lr (11).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">LIVING ROOM DESIGNS</a></h3>
  </div>
</div>



<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/HOME OFFICE DESIGNS/ho (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/HOME OFFICE DESIGNS/ho (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/HOME OFFICE DESIGNS/ho (3).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/HOME OFFICE DESIGNS/ho (4).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/HOME OFFICE DESIGNS/ho (5).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">HOME OFFICE DESIGNS</a></h3>
  </div>
</div>



<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/GUEST BEDROOM DESIGNS/gb (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/GUEST BEDROOM DESIGNS/gb (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/GUEST BEDROOM DESIGNS/gb (3).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/GUEST BEDROOM DESIGNS/gb (4).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/GUEST BEDROOM DESIGNS/gb (5).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/GUEST BEDROOM DESIGNS/gb (6).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/GUEST BEDROOM DESIGNS/gb (7).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/GUEST BEDROOM DESIGNS/gb (8).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">GUEST BEDROOM DESIGNS</a></h3>
  </div>
</div>



<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/TV UNIT DESIGNS/tv (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/TV UNIT DESIGNS/tv (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/TV UNIT DESIGNS/tv (3).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/TV UNIT DESIGNS/tv (4).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/TV UNIT DESIGNS/tv (5).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/TV UNIT DESIGNS/tv (6).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/TV UNIT DESIGNS/tv (7).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/TV UNIT DESIGNS/tv (8).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/TV UNIT DESIGNS/tv (9).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/TV UNIT DESIGNS/tv (10).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/TV UNIT DESIGNS/tv (11).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/TV UNIT DESIGNS/tv (12).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/TV UNIT DESIGNS/tv (13).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">TV UNIT DESIGNS</a></h3>
  </div>
</div>



<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/WINDOW DESIGNS/w (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/WINDOW DESIGNS/w (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/WINDOW DESIGNS/w (3).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/WINDOW DESIGNS/w (4).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">WINDOW DESIGNS</a></h3>
  </div>
</div>



























<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/FALSE CEILING DESIGNS/fc (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/FALSE CEILING DESIGNS/fc (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/FALSE CEILING DESIGNS/fc (3).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/FALSE CEILING DESIGNS/fc (4).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/FALSE CEILING DESIGNS/fc (5).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">FALSE CEILING DESIGNS</a></h3>
  </div>
</div>



<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/KIDS BEDROOM DESIGNS/kb (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/KIDS BEDROOM DESIGNS/kb (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/KIDS BEDROOM DESIGNS/kb (3).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">KIDS BEDROOM DESIGNS</a></h3>
  </div>
</div>




<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/FLOORING DESIGNS/f (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/FLOORING DESIGNS/f (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">FLOORING DESIGNS</a></h3>
  </div>
</div>




<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/WALL DECOR DESIGNS/wd (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/WALL DECOR DESIGNS/wd (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">WALL DECOR DESIGNS</a></h3>
  </div>
</div>



<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
             <img src="images/WALL PAINT DESIGNS/wp (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
             <img src="images/WALL PAINT DESIGNS/wp (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
             <img src="images/WALL PAINT DESIGNS/wp (3).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">WALL PAINT DESIGNS</a></h3>
  </div>
</div>



<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <!-- <img src="images/BALCONY DESIGNS/b (1).jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
              <img src="images/BALCONY DESIGNS/b (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/BALCONY DESIGNS/b (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">BALCONY DESIGNS</a></h3>
  </div>
</div>




<div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
  <!-- <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;"> -->
<div class="owl-carousel owl-3">
              <img src="images/MANDIR DESIGNS/m (1).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
              <img src="images/MANDIR DESIGNS/m (2).jpg" alt="Image" class="img-fluid" style="width: 350px; height: 350px;">
            </div>
  <div class="service-29193 text-center">
    <h3 ><a href="#">MANDIR DESIGNS</a></h3>
  </div>
</div>








          
          <!-- <div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <img src="images/img_1.jpg" alt="Image" class="img-fluid" style="height: 350px;">
            <div class="service-29193 text-center">
              <h3 ><a href="#">MODULAR KITCHEN</a></h3>
            </div>
          </div>

          <div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <img src="images/img_2.jpg" alt="Image" class="img-fluid" style="height: 350px;">
            <div class="service-29193 text-center">
              <h3 ><a href="#">DINING ROOM DESIGNS</a></h3>
            </div>
          </div>

          <div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <img src="images/img_3.jpg" alt="Image" class="img-fluid" style="height: 350px;">
            <div class="service-29193 text-center">
              <h3 ><a href="#">LIVING ROOM DESIGNS</a></h3>
            </div>
          </div>

          <div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <img src="images/img_4.jpg" alt="Image" class="img-fluid" style="height: 350px;">
            <div class="service-29193 text-center">
              <h3 ><a href="#">MASTER BEDROOM DESIGNS</a></h3>
            </div>
          </div> -->




          <!-- <div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <img src="fonts/flaticon/svg/003-lamp.svg" alt="Image" class="img-fluid">
              </span>
              <h3 class="mb-4"><a href="#">Incidunt Distinctio</a></h3>
              <p>Lorem ipsum dolor sit ame adipisicing elit. Perspiciatis incidunt distinctio voluptate .</p>
            </div>
          </div>

          <div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <img src="fonts/flaticon/svg/001-stairs.svg" alt="Image" class="img-fluid">
              </span>
              <h3 class="mb-4"><a href="#">Reiciendis Velit Iure</a></h3>
              <p>Lorem ipsum dolor sit ame adipisicing elit. Perspiciatis incidunt distinctio voluptate .</p>
            </div>
          </div>

          <div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <img src="fonts/flaticon/svg/004-blueprint.svg" alt="Image" class="img-fluid">
              </span>
              <h3 class="mb-4"><a href="#">Boluptate Ipsum</a></h3>
              <p>Lorem ipsum dolor sit ame adipisicing elit. Perspiciatis incidunt distinctio voluptate .</p>
            </div>
          </div>
          <div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <img src="fonts/flaticon/svg/006-pantone.svg" alt="Image" class="img-fluid">
              </span>
              <h3 class="mb-4"><a href="#">Modern Elit</a></h3>
              <p>Lorem ipsum dolor sit ame adipisicing elit. Perspiciatis incidunt distinctio voluptate .</p>
            </div>
          </div>
          <div class="col-md-6 mb-4 col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <img src="fonts/flaticon/svg/005-dinning-table.svg" alt="Image" class="img-fluid">
              </span>
              <h3 class="mb-4"><a href="#">Dolor Sitame</a></h3>
              <p>Lorem ipsum dolor sit ame adipisicing elit. Perspiciatis incidunt distinctio voluptate .</p>
            </div>
          </div> -->
          
        </div>
      </div>
    </div>


  
    <div class="site-section section-4">
      <div class="container">

        <div class="row justify-content-center text-center">
          <div class="col-md-7">
            <div class="slide-one-item owl-carousel">
              <!-- <blockquote class="testimonial-1">
                <span class="quote quote-icon-wrap"><span class="icon-format_quote"></span></span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus totam sit delectus earum facere ex ea sunt, eos?</p>
                <cite><span class="text-black">Mike Dorney</span> &mdash; <span class="text-muted">CEO and Co-Founder</span></cite>
              </blockquote>

              <blockquote class="testimonial-1">
                <span class="quote quote-icon-wrap"><span class="icon-format_quote"></span></span>
                <p>Eligendi earum ad perferendis dolores, dolor quas. Ullam in, eaque mollitia suscipit id aspernatur rerum! Sit quibusdam ullam tempora quis, in voluptatum maiores veritatis recusandae!</p>
                <cite><span class="text-black">James Smith</span> &mdash; <span class="text-muted">CEO and Co-Founder</span></cite>
              </blockquote>

              <blockquote class="testimonial-1">
                <span class="quote quote-icon-wrap"><span class="icon-format_quote"></span></span>
                <p> Officia, eius omnis rem non quis eos excepturi cumque sequi pariatur eaque quasi nihil dicta tempore voluptate culpa, veritatis incidunt voluptatibus qui?</p>
                <cite><span class="text-black">Mike Dorney</span> &mdash; <span class="text-muted">CEO and Co-Founder</span></cite>
              </blockquote> -->

         <!-- <blockquote class="testimonial-1"> -->
          <div class="col-md-12 col-lg-12" data-aos="fade-up" data-aos-delay="100">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <center><img src="fonts/flaticon/svg/002-kitchen.svg" alt="Image" class="img-fluid"></center>
              </span>
              <h3 class="mb-4"><a href="#">Kitchen Interiors</a></h3>
              <p>Kitchen interiors play a crucial role in creating a functional and aesthetically pleasing space include U-shaped, L-shaped designs..</p>
            </div>
          </div>
        <!-- </blockquote> -->

        <div class="col-md-12 col-lg-12" data-aos="fade-up" data-aos-delay="200">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <center><img src="fonts/flaticon/svg/003-lamp.svg" alt="Image" class="img-fluid"></center>
              </span>
              <h3 class="mb-4"><a href="#">Modular Interiors</a></h3>
              <p>This concept is widely used in various areas of interior design, including kitchens, living rooms, bedrooms, and office spaces.</p>
            </div>
          </div>

          <div class="col-md-12 col-lg-12" data-aos="fade-up" data-aos-delay="">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <center><img src="fonts/flaticon/svg/001-stairs.svg" alt="Image" class="img-fluid"></center>
              </span>
              <h3 class="mb-4"><a href="#">Full Home Interiors</a></h3>
              <p>Designing the interiors of an entire home involves considering various aspects to create a cohesive and functional living space.</p>
            </div>
          </div>

          <div class="col-md-12 col-lg-12" data-aos="fade-up" data-aos-delay="">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <center><img src="fonts/flaticon/svg/004-blueprint.svg" alt="Image" class="img-fluid"></center>
              </span>
              <h3 class="mb-4"><a href="#">Commercial Interiors</a></h3>
              <p>Designing commercial interiors are not only aesthetically pleasing but also functional and conducive to the specific activities and needs of the business.</p>
            </div>
          </div>
          <div class="col-md-12 col-lg-12" data-aos="fade-up" data-aos-delay="200">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <center><img src="fonts/flaticon/svg/006-pantone.svg" alt="Image" class="img-fluid"></center>
              </span>
              <h3 class="mb-4"><a href="#">Renovations</a></h3>
              <p>Renovations involve making improvements or changes to an existing space to enhance its functionality, aesthetics, or both.</p>
            </div>
          </div>
          <div class="col-md-12 col-lg-12" data-aos="fade-up" data-aos-delay="100">
            <div class="service-29193 text-center">
              <span class="img-wrap mb-5">
                <center><img src="fonts/flaticon/svg/005-dinning-table.svg" alt="Image" class="img-fluid"></center>
              </span>
              <h3 class="mb-4"><a href="#">Furniture & decor</a></h3>
              <p>Furniture and decor play a crucial role in shaping the overall look and feel of a space, be it a home, office, or commercial establishment.</p>
            </div>
          </div>


            </div>
          </div>
        </div>
      </div>
    </div>
    
<?php include "include/footer.php"; ?>

 
