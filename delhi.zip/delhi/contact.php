<?php include "include/header.php"; ?>





<!-- <div class="owl-carousel-wrapper"><br><br><br>

      
    <div class="box-92819 shadow-lg">
        

          <div>
            <h1 class=" mb-3 text-black">Get In Touch</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quam, ratione earum.</p>
          </div>
        
      </div>

        <div class="ftco-cover-1" style="background-image: url('images/hero_1.jpg'); height: 50%;"></div>
    </div>  -->
<br>

    <center> <h3 style="font-family: popins;">Contact Us...</h3></center>

        <iframe class="mb-4 mb-lg-0" src="https://maps.google.com/maps?q=Ground%20Floor,%208861,%20Beri%20wala%20Bagh,%20Shiva%20SalesCorporation,%20Karol%20Bagh,%20New%20Delhi,%20Central%20Delhi,%20Delhi-110005&amp;t=&amp;z=13&amp;ie=UTF8&amp;iwloc=&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" frameborder="0" style="border:0; width: 100%; height: 384px;
          " allowfullscreen></iframe>
       


    
    <div class="site-section">
      <div class="container">
        
        <div class="row">
          <div class="col-lg-8 mb-5" >





            <form action="#" method="post">
              <div class="form-group row">
                <div class="col-md-6 mb-4 mb-lg-0">
                  <input type="text" class="form-control" placeholder="Full Name" id="name">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control" placeholder="Mobile Number" id="MobileNumber">
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-12">
                  <input type="text" class="form-control" placeholder="Email address" id="email">
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-12">
                  <textarea name="" id="Message" class="form-control" placeholder="Write your message." cols="30" rows="10"></textarea>
                </div>
              </div>
              <div class="form-group row">
                <div class="col-md-6 mr-auto">
                         <input type="submit" class="btn btn-block btn-primary text-white py-3 px-5 rounded-0" value="Send Message" onclick="gotowhatsapp()">
                </div>
              </div>
            </form>




<script>
    function gotowhatsapp() {

        var name = document.getElementById("name").value;
        var phone = document.getElementById("MobileNumber").value;
        var email = document.getElementById("email").value;
        var Message = document.getElementById("Message").value;


        var url = "https://wa.me/+919811571061?text=" +
            "Name: " + name + "%0a" +
            "Phone: " + phone + "%0a" +
            "email : " + email + "%0a" +
            "Working Status : " + Message;;

        window.open(url, '_blank').focus();
    }
</script>








          </div>
          <div class="col-lg-4 ml-auto">
            <div class="bg-white p-3 p-md-5">
              <h3 class="heading-39291">Contact Info</h3>
              <ul class="list-unstyled footer-link">
                <li class="d-block mb-3">
                  <span class="d-block text-black small text-uppercase font-weight-bold">Address:</span>
                  <span>Ground Floor, 8861, Beri wala Bagh, Shiva SalesCorporation, Karol Bagh, New Delhi, Central Delhi, Delhi-110005</span></li>
                <li class="d-block mb-3"><span class="d-block text-black small text-uppercase font-weight-bold">Phone:</span><span>+919811571061</span></li>
                <li class="d-block mb-3"><span class="d-block text-black small text-uppercase font-weight-bold">Email:</span><span>buildistan@outlook.com</span></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    
    <!-- <div class="site-section section-4">
      <div class="container">

        <div class="row justify-content-center text-center">
          <div class="col-md-7">
            <div class="slide-one-item owl-carousel">
              <blockquote class="testimonial-1">
                <span class="quote quote-icon-wrap"><span class="icon-format_quote"></span></span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus totam sit delectus earum facere ex ea sunt, eos?</p>
                <cite><span class="text-black">Mike Dorney</span> &mdash; <span class="text-muted">CEO and Co-Founder</span></cite>
              </blockquote>

              <blockquote class="testimonial-1">
                <span class="quote quote-icon-wrap"><span class="icon-format_quote"></span></span>
                <p>Eligendi earum ad perferendis dolores, dolor quas. Ullam in, eaque mollitia suscipit id aspernatur rerum! Sit quibusdam ullam tempora quis, in voluptatum maiores veritatis recusandae!</p>
                <cite><span class="text-black">James Smith</span> &mdash; <span class="text-muted">CEO and Co-Founder</span></cite>
              </blockquote>

              <blockquote class="testimonial-1">
                <span class="quote quote-icon-wrap"><span class="icon-format_quote"></span></span>
                <p> Officia, eius omnis rem non quis eos excepturi cumque sequi pariatur eaque quasi nihil dicta tempore voluptate culpa, veritatis incidunt voluptatibus qui?</p>
                <cite><span class="text-black">Mike Dorney</span> &mdash; <span class="text-muted">CEO and Co-Founder</span></cite>
              </blockquote>
            </div>
          </div>
        </div>
      </div>
    </div> -->
    
<?php include "include/footer.php"; ?>
    
