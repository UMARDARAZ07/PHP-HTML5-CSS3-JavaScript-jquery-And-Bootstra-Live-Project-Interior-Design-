<?php include "include/header.php"; ?>





    <div class="owl-carousel-wrapper">

      

<!--       <div class="box-92819 shadow-lg">
        

          <div>
            <h1 class=" mb-3 text-black">About The Company</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quam, ratione earum.</p>
          </div>
        
      </div>

        <div class="ftco-cover-1" style="background-image: url('images/hero_1.jpg');"></div>
    </div> -->

    
    <div class="site-section">
      <div class="container">
        <div class="row align-items-stretch">
          <div class="col-lg-4">
            <div class="h-100 bg-white box-29291">
              <h2 class="heading-39291">Why Choose us..</h2>
              <p>We have a team with Innovative ideas and with a creative mind as in our interior design business involves highlighting our passion, expertise, and unique approach to design. Emphasize our team's dedication to creating personalized and functional spaces that reflect clients' lifestyles. Share our design philosophy and any notable projects to establish credibility. Remember to convey a welcoming tone that resonates with potential clients seeking a creative and reliable interior design partner. We believe in modernization and in the modern world we approach the client's satisfaction.</p>

             
            </div>
          </div>
          <div class="col-lg-8">
            <div class="owl-carousel owl-3">
              <img src="images/a2.jpg" alt="Image" class="img-fluid" style="width: 800px; height: 830px;">
              <img src="images/a4.jpg" alt="Image" class="img-fluid" style="width: 800px; height: 830px;">
              <img src="images/a3.jpg" alt="Image" class="img-fluid" style="width: 800px; height: 830px;">
              <img src="images/a1.jpg" alt="Image" class="img-fluid" style="width: 800px; height: 830px;">
              <img src="images/a5.jpg" alt="Image" class="img-fluid" style="width: 800px; height: 830px;">
              <img src="images/a6.jpg" alt="Image" class="img-fluid" style="width: 800px; height: 830px;">
              <img src="images/a7.jpg" alt="Image" class="img-fluid" style="width: 800px; height: 830px;">
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section bg-light">
      <div class="container">
        <div class="row justify-content-center text-center mb-5 section-2-title">
          <div class="col-md-6">
            <h2 class="heading-39291">CUSTOMER REVIEWS</h2>
            <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis provident eius ratione velit, voluptas laborum nemo quas ad necessitatibus placeat?</p> -->
          </div>
        </div>
        <div class="row align-items-stretch">

          <div class="col-lg-4 col-md-6 mb-5">
            <div class="post-entry-1 h-100 bg-white text-center">
              <a href="#" class="d-inline-block">
                <img src="images/person_1.jpg" alt="Image"
                 class="img-fluid">
              </a>
              <div class="post-entry-1-contents">
                <!-- <span class="meta">Founder</span> -->
                <h2>Mec</h2>
                <p>Look for inconsistencies in the language, details, or claims made in the reviews. Genuine reviews typically provide specific and honest feedback.</p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mb-5">
            <div class="post-entry-1 h-100 bg-white text-center">
              <a href="#" class="d-inline-block">
                <img src="images/person_2.jpg" alt="Image"
                 class="img-fluid">
              </a>
              <div class="post-entry-1-contents">
                <!-- <span class="meta">Founder</span> -->
                <h2>Kely</h2>
                <p>Examine the profiles of reviewers. If multiple reviews come from suspicious or newly created accounts, it could be a sign of fake reviews.</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mb-5">
            <div class="post-entry-1 h-100 bg-white text-center">
              <a href="#" class="d-inline-block">
                <img src="images/person_3.jpg" alt="Image"
                 class="img-fluid">
              </a>
              <div class="post-entry-1-contents">
                <!-- <span class="meta">Founder</span> -->
                <h2>jeny</h2>
                <p>Analyze the patterns of reviews. If there's a sudden influx of positive or negative reviews within a short period, it may indicate manipulation.</p>
              </div>
            </div>
          </div>

          <!-- <div class="col-lg-4 col-md-6 mb-5">
            <div class="post-entry-1 h-100 bg-white text-center">
              <a href="#" class="d-inline-block">
                <img src="images/person_4.jpg" alt="Image"
                 class="img-fluid">
              </a>
              <div class="post-entry-1-contents">
                <span class="meta">Founder</span>
                <h2>James Doe</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa, sapiente.</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mb-5">
            <div class="post-entry-1 h-100 bg-white text-center">
              <a href="#" class="d-inline-block">
                <img src="images/person_5.jpg" alt="Image"
                 class="img-fluid">
              </a>
              <div class="post-entry-1-contents">
                <span class="meta">Founder</span>
                <h2>James Doe</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa, sapiente.</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mb-5">
            <div class="post-entry-1 h-100 bg-white text-center">
              <a href="#" class="d-inline-block">
                <img src="images/person_1.jpg" alt="Image"
                 class="img-fluid">
              </a>
              <div class="post-entry-1-contents">
                <span class="meta">Founder</span>
                <h2>James Doe</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa, sapiente.</p>
              </div>
            </div>
          </div> -->


        </div>
      </div>
    </div>


    
<!--     <div class="site-section section-4">
      <div class="container">

        <div class="row justify-content-center text-center">
          <div class="col-md-7">
            <div class="slide-one-item owl-carousel">
              <blockquote class="testimonial-1">
                <span class="quote quote-icon-wrap"><span class="icon-format_quote"></span></span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus totam sit delectus earum facere ex ea sunt, eos?</p>
                <cite><span class="text-black">Mike Dorney</span> &mdash; <span class="text-muted">CEO and Co-Founder</span></cite>
              </blockquote>

              <blockquote class="testimonial-1">
                <span class="quote quote-icon-wrap"><span class="icon-format_quote"></span></span>
                <p>Eligendi earum ad perferendis dolores, dolor quas. Ullam in, eaque mollitia suscipit id aspernatur rerum! Sit quibusdam ullam tempora quis, in voluptatum maiores veritatis recusandae!</p>
                <cite><span class="text-black">James Smith</span> &mdash; <span class="text-muted">CEO and Co-Founder</span></cite>
              </blockquote>

              <blockquote class="testimonial-1">
                <span class="quote quote-icon-wrap"><span class="icon-format_quote"></span></span>
                <p> Officia, eius omnis rem non quis eos excepturi cumque sequi pariatur eaque quasi nihil dicta tempore voluptate culpa, veritatis incidunt voluptatibus qui?</p>
                <cite><span class="text-black">Mike Dorney</span> &mdash; <span class="text-muted">CEO and Co-Founder</span></cite>
              </blockquote>
            </div>
          </div>
        </div>
      </div>
    </div> -->
  
  <hr>  

    
<?php include "include/footer.php"; ?>
